1. Langauge and version: python 3
2. Libraries: pandas
3. How to run: Please keep 'myStrategy()' and 'calcPrice()' functions and call 'myStrategy()' as spec.

p.s. This is a simple version of buy-low-sell-high algorithm which can roughly earn 300% ROI from Jan. 1993 to today.